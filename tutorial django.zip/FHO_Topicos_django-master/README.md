FHO_Tópicos

### Como desenvolver ?

1. Clone o repositório
2. Crie um virtualenv 
3. Ative a virtualenv
4. Instale as dependências

```console
git clone https://github.com/orlandosaraivajr/FHO_Topicos_django.git
cd FHO_Topicos_django/
virtualenv venv -p python3
source venv/bin/activate
pip install -r requirements.txt 
cd mysite/
python manage.py runserver
```
